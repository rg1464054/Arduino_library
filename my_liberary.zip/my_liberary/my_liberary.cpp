#include "my_liberary.h"
int addTwoInts(int a,int b)
{
  return a+b;

}