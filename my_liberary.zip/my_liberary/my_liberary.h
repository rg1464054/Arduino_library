#ifndef MY_LIBERARY_H//this can be in any globle folder
#define MY_LIBERARY_H
//after define before function 
#include <Arduino.h>//to take the functionalities of arduino in my liberary

int addTwoInts(int a,int b);


#endif
